CREATE VIEW `view1` AS
  SELECT
    `mydb`.`jsj46_s141`.`SNO`    AS `SNO`,
    `mydb`.`jsj46_s141`.`SNAME`  AS `SNAME`,
    `mydb`.`jsj46_s141`.`BDATE`  AS `BDATE`,
    `mydb`.`jsj46_s141`.`HEIGHT` AS `HEIGHT`
  FROM `mydb`.`jsj46_s141`
  WHERE ((`mydb`.`jsj46_s141`.`DORM` LIKE '东18舍%') AND (`mydb`.`jsj46_s141`.`GENDER` = '男'))