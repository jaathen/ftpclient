CREATE VIEW `view2` AS
  SELECT
    `mydb`.`jsj46_c141`.`CNO`     AS `CNO`,
    `mydb`.`jsj46_c141`.`CNAME`   AS `CNAME`,
    `mydb`.`jsj46_c141`.`PERIOD`  AS `PERIOD`,
    `mydb`.`jsj46_c141`.`CREDIT`  AS `CREDIT`,
    `mydb`.`jsj46_c141`.`TEACHER` AS `TEACHER`
  FROM `mydb`.`jsj46_c141`
  WHERE (`mydb`.`jsj46_c141`.`TEACHER` = '张明')