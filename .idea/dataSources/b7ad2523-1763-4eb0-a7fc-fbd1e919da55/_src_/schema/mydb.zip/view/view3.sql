CREATE VIEW `view3` AS
  SELECT
    `mydb`.`jsj46_s141`.`SNO`    AS `SNO`,
    `mydb`.`jsj46_s141`.`SNAME`  AS `SNAME`,
    `mydb`.`jsj46_sc141`.`GRADE` AS `GRADE`
  FROM `mydb`.`jsj46_c141`
    JOIN `mydb`.`jsj46_s141`
    JOIN `mydb`.`jsj46_sc141`
  WHERE ((`mydb`.`jsj46_c141`.`CNAME` = '人工智能') AND (`mydb`.`jsj46_c141`.`CNO` = `mydb`.`jsj46_sc141`.`CNO`) AND
         (`mydb`.`jsj46_s141`.`SNO` = `mydb`.`jsj46_sc141`.`SNO`))